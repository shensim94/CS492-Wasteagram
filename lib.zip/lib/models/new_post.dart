class NewPost{
  String? title;
  String? url;
  int? itemCount;
  String? postLocation;
  NewPost({this.title, this.url, this.itemCount, this.postLocation});
}